'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useORMStore } from '@/store/ormStore';
import { FiUpload, FiCheckCircle, FiAlertCircle } from 'react-icons/fi';
import { useDropzone } from 'react-dropzone';

export default function AnswerKey() {
  const router = useRouter();
  const {
    currentSheet,
    isSubmitted,
    setAnswerKey,
  } = useORMStore();
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [isProcessed, setIsProcessed] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [manualAnswerKey, setManualAnswerKey] = useState<Record<number, string>>({});
  const [inputMode, setInputMode] = useState<'file' | 'manual'>('file');
  
  useEffect(() => {
    if (!isSubmitted || !currentSheet) {
      router.push('/');
    }
  }, [isSubmitted, currentSheet, router]);
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'text/*': ['.txt', '.csv'],
      'application/vnd.ms-excel': ['.xls', '.xlsx'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
    },
    maxFiles: 1,
    onDrop: (acceptedFiles) => {
      if (acceptedFiles.length > 0) {
        processFile(acceptedFiles[0]);
      }
    },
  });
  
  const processFile = async (file: File) => {
    setIsProcessing(true);
    setError(null);
    
    try {
      // In a real application, you would send the file to your API endpoint
      // that would extract the answer key using AI or parsing
      
      // For this demo, we'll simulate processing with a timeout
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simulate extracting answers - in a real app, this would come from the API
      const answerKey: Record<number, string> = {};
      
      if (currentSheet) {
        // Generate random answers for demo purposes
        const options = ['A', 'B', 'C', 'D'];
        currentSheet.questions.forEach(question => {
          const randomIndex = Math.floor(Math.random() * options.length);
          answerKey[question.number] = options[randomIndex];
        });
        
        setAnswerKey(answerKey);
        setIsProcessed(true);
        
        // Navigate to results after a short delay
        setTimeout(() => {
          router.push('/results');
        }, 1000);
      }
    } catch (error) {
      console.error('Error processing file:', error);
      setError('Failed to process the answer key file. Please try again or use manual entry.');
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleManualSubmit = () => {
    if (Object.keys(manualAnswerKey).length === 0) {
      setError('Please enter at least one answer');
      return;
    }
    
    setAnswerKey(manualAnswerKey);
    setIsProcessed(true);
    
    // Navigate to results after a short delay
    setTimeout(() => {
      router.push('/results');
    }, 1000);
  };
  
  const handleSkip = () => {
    router.push('/results');
  };
  
  const handleAnswerChange = (questionNumber: number, value: string) => {
    if (!value || /^[A-Da-d]$/.test(value)) {
      setManualAnswerKey(prev => ({
        ...prev,
        [questionNumber]: value.toUpperCase()
      }));
    }
  };
  
  if (!currentSheet) {
    return null;
  }
  
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Answer Key</h1>
      
      <div className="card mb-6">
        <h2 className="text-xl font-bold mb-4">Provide Answer Key</h2>
        
        <div className="mb-6">
          <div className="flex border-b border-gray-200 dark:border-gray-700 mb-4">
            <button
              className={`py-2 px-4 ${
                inputMode === 'file'
                  ? 'border-b-2 border-indigo-500 text-indigo-600 dark:text-indigo-400'
                  : 'text-gray-500 dark:text-gray-400'
              }`}
              onClick={() => setInputMode('file')}
            >
              Upload File
            </button>
            <button
              className={`py-2 px-4 ${
                inputMode === 'manual'
                  ? 'border-b-2 border-indigo-500 text-indigo-600 dark:text-indigo-400'
                  : 'text-gray-500 dark:text-gray-400'
              }`}
              onClick={() => setInputMode('manual')}
            >
              Manual Entry
            </button>
          </div>
          
          {inputMode === 'file' ? (
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                Upload a file containing the answer key. The system will automatically extract the answers.
              </p>
              
              {isProcessed ? (
                <div className="flex items-center gap-2 text-green-600 dark:text-green-400 mb-4">
                  <FiCheckCircle />
                  <span>Answer key processed successfully! Redirecting to results...</span>
                </div>
              ) : (
                <div
                  {...getRootProps()}
                  className={`border-2 border-dashed rounded-md p-6 text-center cursor-pointer ${
                    isDragActive 
                      ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-900/20' 
                      : 'border-gray-300 dark:border-gray-700'
                  }`}
                >
                  <input {...getInputProps()} />
                  
                  {isProcessing ? (
                    <div className="text-center py-4">
                      <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 dark:border-indigo-400"></div>
                      <p className="mt-2 text-gray-600 dark:text-gray-400">Processing answer key...</p>
                    </div>
                  ) : (
                    <div className="text-center">
                      <FiUpload className="mx-auto text-gray-400 text-3xl mb-2" />
                      <p className="text-gray-600 dark:text-gray-400">
                        {isDragActive
                          ? 'Drop the file here'
                          : 'Drag & drop your answer key file, or click to select'}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                        Supported formats: TXT, CSV, Excel
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                Enter the correct answers manually. Only enter answers for questions you want to check.
              </p>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 mb-4">
                {currentSheet.questions.map(question => (
                  <div key={question.id} className="flex items-center">
                    <label className="w-8 text-gray-700 dark:text-gray-300">{question.number}.</label>
                    <input
                      type="text"
                      className="input-field w-12 text-center"
                      value={manualAnswerKey[question.number] || ''}
                      onChange={(e) => handleAnswerChange(question.number, e.target.value)}
                      placeholder="A-D"
                      maxLength={1}
                    />
                  </div>
                ))}
              </div>
              
              <button
                className="btn-primary w-full"
                onClick={handleManualSubmit}
                disabled={Object.keys(manualAnswerKey).length === 0}
              >
                Submit Answer Key
              </button>
            </div>
          )}
          
          {error && (
            <div className="mt-4 p-3 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-md flex items-start gap-2">
              <FiAlertCircle className="mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mt-4">
          <button
            className="btn-secondary"
            onClick={handleSkip}
          >
            Skip and View Results
          </button>
          <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">
            You can view your results without providing an answer key, but correct answers won't be shown.
          </p>
        </div>
      </div>
    </div>
  );
}