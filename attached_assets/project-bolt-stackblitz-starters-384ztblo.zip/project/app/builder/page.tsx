'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useORMStore } from '@/store/ormStore';
import { FiPlus, FiTrash2, FiCheck } from 'react-icons/fi';

export default function Builder() {
  const router = useRouter();
  const {
    currentSheet,
    addQuestion,
    updateQuestion,
    removeQuestion,
    addOption,
    updateOption,
    removeOption,
    setCorrectOption,
  } = useORMStore();
  
  const [newQuestionText, setNewQuestionText] = useState('');
  const [newOptionTexts, setNewOptionTexts] = useState<Record<string, string>>({});
  
  if (!currentSheet) {
    router.push('/');
    return null;
  }
  
  const handleAddQuestion = () => {
    if (!newQuestionText) return;
    
    addQuestion(newQuestionText);
    setNewQuestionText('');
  };
  
  const handleAddOption = (questionId: string) => {
    const optionText = newOptionTexts[questionId];
    if (!optionText) return;
    
    addOption(questionId, optionText);
    setNewOptionTexts((prev) => ({ ...prev, [questionId]: '' }));
  };
  
  const handleStartTest = () => {
    router.push('/test');
  };
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">{currentSheet.title}</h1>
        <button
          className="btn-primary"
          onClick={handleStartTest}
          disabled={currentSheet.questions.length === 0}
        >
          Start Test
        </button>
      </div>
      
      <div className="card mb-6">
        <h2 className="text-xl font-bold mb-4">Add New Question</h2>
        <div className="flex gap-2">
          <input
            type="text"
            className="input-field flex-grow"
            value={newQuestionText}
            onChange={(e) => setNewQuestionText(e.target.value)}
            placeholder="Enter question text"
          />
          <button
            className="btn-primary flex items-center gap-1"
            onClick={handleAddQuestion}
            disabled={!newQuestionText}
          >
            <FiPlus /> Add
          </button>
        </div>
      </div>
      
      {currentSheet.questions.length === 0 ? (
        <div className="card text-center py-8">
          <p className="text-gray-500 dark:text-gray-400">No questions added yet. Add your first question above.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {currentSheet.questions.map((question) => (
            <div key={question.id} className="card">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-grow">
                  <input
                    type="text"
                    className="input-field w-full"
                    value={question.text}
                    onChange={(e) => updateQuestion(question.id, e.target.value)}
                    placeholder="Question text"
                  />
                </div>
                <button
                  className="ml-2 p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md"
                  onClick={() => removeQuestion(question.id)}
                >
                  <FiTrash2 />
                </button>
              </div>
              
              <div className="ml-4 space-y-2">
                {question.options.map((option) => (
                  <div key={option.id} className="flex items-center gap-2">
                    <button
                      className={`w-6 h-6 rounded-full flex items-center justify-center ${
                        question.correctOption === option.id
                          ? 'bg-green-500 text-white'
                          : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-300 dark:hover:bg-gray-600'
                      }`}
                      onClick={() => setCorrectOption(question.id, option.id)}
                    >
                      {question.correctOption === option.id && <FiCheck size={16} />}
                    </button>
                    <input
                      type="text"
                      className="input-field flex-grow"
                      value={option.text}
                      onChange={(e) => updateOption(question.id, option.id, e.target.value)}
                      placeholder="Option text"
                    />
                    <button
                      className="p-1 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md"
                      onClick={() => removeOption(question.id, option.id)}
                    >
                      <FiTrash2 size={16} />
                    </button>
                  </div>
                ))}
                
                <div className="flex gap-2 mt-2">
                  <input
                    type="text"
                    className="input-field flex-grow"
                    value={newOptionTexts[question.id] || ''}
                    onChange={(e) =>
                      setNewOptionTexts((prev) => ({
                        ...prev,
                        [question.id]: e.target.value,
                      }))
                    }
                    placeholder="Add new option"
                  />
                  <button
                    className="btn-secondary flex items-center gap-1"
                    onClick={() => handleAddOption(question.id)}
                    disabled={!newOptionTexts[question.id]}
                  >
                    <FiPlus /> Add
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}