import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { ThemeProvider } from '@/components/ThemeProvider';
import ThemeToggle from '@/components/ThemeToggle';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'ORM Sheet Builder',
  description: 'Build and analyze ORM sheets with AI assistance',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <div className="min-h-screen">
            <header className="bg-indigo-600 dark:bg-indigo-800 text-white p-4">
              <div className="container mx-auto flex justify-between items-center">
                <h1 className="text-2xl font-bold">ORM Sheet Builder</h1>
                <ThemeToggle />
              </div>
            </header>
            <main className="container mx-auto py-8 px-4">
              {children}
            </main>
            <footer className="bg-gray-100 dark:bg-slate-900 p-4 text-center text-gray-600 dark:text-gray-400">
              <div className="container mx-auto">
                <p>© 2025 ORM Sheet Builder. All rights reserved.</p>
              </div>
            </footer>
          </div>
        </ThemeProvider>
      </body>
    </html>
  );
}