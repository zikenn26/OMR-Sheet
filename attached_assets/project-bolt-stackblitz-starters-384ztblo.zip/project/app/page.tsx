'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useORMStore } from '@/store/ormStore';

export default function Home() {
  const router = useRouter();
  const createSheet = useORMStore((state) => state.createSheet);
  const generateQuestions = useORMStore((state) => state.generateQuestions);
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [timeLimit, setTimeLimit] = useState(30);
  const [startNumber, setStartNumber] = useState(1);
  const [endNumber, setEndNumber] = useState(50);
  const [marksPerCorrect, setMarksPerCorrect] = useState(1);
  const [marksPerIncorrect, setMarksPerIncorrect] = useState(0);
  
  const handleCreateSheet = () => {
    if (!title) return;
    if (startNumber > endNumber) return;
    
    createSheet(title, description, timeLimit, startNumber, endNumber, marksPerCorrect, marksPerIncorrect);
    generateQuestions();
    router.push('/test');
  };
  
  return (
    <div className="max-w-2xl mx-auto">
      <div className="card">
        <h2 className="text-2xl font-bold mb-6">Create a New ORM Sheet</h2>
        
        <div className="space-y-4">
          <div>
            <label htmlFor="title" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">
              Title
            </label>
            <input
              id="title"
              type="text"
              className="input-field"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter sheet title"
            />
          </div>
          
          <div>
            <label htmlFor="description" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">
              Description
            </label>
            <textarea
              id="description"
              className="input-field"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter sheet description"
              rows={3}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="startNumber" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">
                Starting Question Number
              </label>
              <input
                id="startNumber"
                type="number"
                className="input-field"
                value={startNumber}
                onChange={(e) => setStartNumber(Number(e.target.value))}
                min={1}
                max={999}
              />
            </div>
            
            <div>
              <label htmlFor="endNumber" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">
                Ending Question Number
              </label>
              <input
                id="endNumber"
                type="number"
                className="input-field"
                value={endNumber}
                onChange={(e) => setEndNumber(Number(e.target.value))}
                min={startNumber}
                max={1000}
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="timeLimit" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">
              Time Limit (minutes)
            </label>
            <input
              id="timeLimit"
              type="number"
              className="input-field"
              value={timeLimit}
              onChange={(e) => setTimeLimit(Number(e.target.value))}
              min={1}
              max={180}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="marksPerCorrect" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">
                Marks per Correct Answer
              </label>
              <input
                id="marksPerCorrect"
                type="number"
                className="input-field"
                value={marksPerCorrect}
                onChange={(e) => setMarksPerCorrect(Number(e.target.value))}
                min={0}
                step={0.5}
              />
            </div>
            
            <div>
              <label htmlFor="marksPerIncorrect" className="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">
                Negative Marks per Wrong Answer
              </label>
              <input
                id="marksPerIncorrect"
                type="number"
                className="input-field"
                value={marksPerIncorrect}
                onChange={(e) => setMarksPerIncorrect(Number(e.target.value))}
                min={0}
                step={0.25}
              />
            </div>
          </div>
          
          <button
            className="btn-primary w-full mt-6"
            onClick={handleCreateSheet}
            disabled={!title || startNumber > endNumber}
          >
            Create and Start Test
          </button>
        </div>
      </div>
      
      <div className="mt-8 card">
        <h2 className="text-xl font-bold mb-4">How It Works</h2>
        <ol className="list-decimal pl-5 space-y-2 text-gray-800 dark:text-gray-200">
          <li>Enter the question range (e.g., 1-50)</li>
          <li>Set the time limit for the test</li>
          <li>Define marks for correct and incorrect answers</li>
          <li>Take the test by selecting options A, B, C, or D</li>
          <li>Upload an answer key file after completion</li>
          <li>Get instant results and a detailed summary</li>
        </ol>
      </div>
    </div>
  );
}