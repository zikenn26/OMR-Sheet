'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useORMStore } from '@/store/ormStore';
import { FiCheckCircle, FiXCircle, FiHelpCircle } from 'react-icons/fi';

export default function Results() {
  const router = useRouter();
  const {
    currentSheet,
    submissionResults,
    submissionSummary,
    isSubmitted,
    resetSubmission,
  } = useORMStore();
  
  useEffect(() => {
    if (!isSubmitted || !currentSheet) {
      router.push('/');
    }
  }, [isSubmitted, currentSheet, router]);
  
  const handleRetake = () => {
    resetSubmission();
    router.push('/test');
  };
  
  const handleNewSheet = () => {
    resetSubmission();
    router.push('/');
  };
  
  if (!currentSheet || !submissionSummary || !submissionResults.length) {
    return null;
  }
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins} min ${secs} sec`;
  };
  
  // Group questions by pages for better organization
  const questionsPerPage = 20;
  const pages = [];
  for (let i = 0; i < submissionResults.length; i += questionsPerPage) {
    pages.push(submissionResults.slice(i, i + questionsPerPage));
  }
  
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Test Results</h1>
      
      <div className="card mb-8">
        <h2 className="text-xl font-bold mb-4">Summary</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-indigo-50 dark:bg-indigo-900/30 p-4 rounded-lg">
            <p className="text-sm text-indigo-600 dark:text-indigo-400">Score</p>
            <p className="text-2xl font-bold">{submissionSummary.score.toFixed(1)}%</p>
          </div>
          
          <div className="bg-green-50 dark:bg-green-900/30 p-4 rounded-lg">
            <p className="text-sm text-green-600 dark:text-green-400">Correct Answers</p>
            <p className="text-2xl font-bold">
              {submissionSummary.correctAnswers} / {submissionSummary.totalQuestions}
            </p>
          </div>
          
          <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg">
            <p className="text-sm text-blue-600 dark:text-blue-400">Time Taken</p>
            <p className="text-2xl font-bold">{formatTime(submissionSummary.timeTaken)}</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="bg-purple-50 dark:bg-purple-900/30 p-4 rounded-lg">
            <p className="text-sm text-purple-600 dark:text-purple-400">Total Marks</p>
            <p className="text-2xl font-bold">
              {submissionSummary.totalMarks.toFixed(1)}
            </p>
          </div>
          
          <div className="bg-orange-50 dark:bg-orange-900/30 p-4 rounded-lg">
            <p className="text-sm text-orange-600 dark:text-orange-400">Marking Scheme</p>
            <p className="text-lg">
              +{currentSheet.marksPerCorrect} correct / -{currentSheet.marksPerIncorrect} incorrect
            </p>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-4">
          <button className="btn-primary" onClick={handleRetake}>
            Retake Test
          </button>
          <button className="btn-secondary" onClick={handleNewSheet}>
            Create New Sheet
          </button>
        </div>
      </div>
      
      <div className="card">
        <h2 className="text-xl font-bold mb-4">Detailed Results</h2>
        
        {pages.map((page, pageIndex) => (
          <div key={pageIndex} className="mb-6 last:mb-0">
            <h3 className="font-medium text-gray-700 dark:text-gray-300 mb-3">
              Questions {page[0].questionNumber} - {page[page.length - 1].questionNumber}
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {page.map((result) => {
                const question = currentSheet.questions.find(q => q.id === result.questionId);
                if (!question) return null;
                
                const userOption = question.options.find(o => o.id === result.userAnswer);
                const correctOption = question.options.find(o => o.id === result.correctAnswer);
                
                return (
                  <div key={result.questionId} className="border border-gray-200 dark:border-gray-700 rounded-md p-3">
                    <div className="flex items-start gap-2">
                      {result.isCorrect ? (
                        <FiCheckCircle className="text-green-500 mt-1 flex-shrink-0" />
                      ) : result.userAnswer ? (
                        <FiXCircle className="text-red-500 mt-1 flex-shrink-0" />
                      ) : (
                        <FiHelpCircle className="text-yellow-500 mt-1 flex-shrink-0" />
                      )}
                      
                      <div>
                        <h4 className="font-medium">
                          {question.number}.
                        </h4>
                        
                        {userOption && (
                          <p className={`mt-1 text-sm ${result.isCorrect ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                            Your answer: {userOption.label}
                          </p>
                        )}
                        
                        {!result.isCorrect && correctOption && (
                          <p className="mt-1 text-sm text-green-600 dark:text-green-400">
                            Correct: {correctOption.label}
                          </p>
                        )}
                        
                        {!userOption && (
                          <p className="mt-1 text-sm text-yellow-600 dark:text-yellow-400">
                            Not answered
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}