'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useORMStore } from '@/store/ormStore';
import { FiClock, FiUpload, FiCheckCircle } from 'react-icons/fi';
import { useDropzone } from 'react-dropzone';

export default function Test() {
  const router = useRouter();
  const {
    currentSheet,
    userAnswers,
    setUserAnswer,
    submitAnswers,
    isSubmitted,
  } = useORMStore();
  
  const [timeLeft, setTimeLeft] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(true);
  const [startTime] = useState(Date.now());
  const [currentPage, setCurrentPage] = useState(1);
  const [questionsPerPage] = useState(10);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  useEffect(() => {
    if (!currentSheet) {
      router.push('/');
      return;
    }
    
    setTimeLeft(currentSheet.timeLimit * 60);
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [currentSheet, router]);
  
  useEffect(() => {
    if (!isTimerRunning || timeLeft <= 0) return;
    
    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isTimerRunning, timeLeft]);
  
  const handleSubmit = () => {
    if (isSubmitted) return;
    
    const timeTaken = Math.floor((Date.now() - startTime) / 1000);
    submitAnswers(timeTaken);
    setIsTimerRunning(false);
    router.push('/answer-key');
  };
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  if (!currentSheet) {
    return null;
  }
  
  const totalPages = Math.ceil(currentSheet.questions.length / questionsPerPage);
  const startIdx = (currentPage - 1) * questionsPerPage;
  const endIdx = Math.min(startIdx + questionsPerPage, currentSheet.questions.length);
  const currentQuestions = currentSheet.questions.slice(startIdx, endIdx);
  
  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">{currentSheet.title}</h1>
        <div className="flex items-center gap-4">
          <div className="timer flex items-center gap-2">
            <FiClock className="text-red-500" />
            <span className={timeLeft < 60 ? 'text-red-500' : ''}>
              {formatTime(timeLeft)}
            </span>
          </div>
          <button className="btn-primary" onClick={handleSubmit}>
            Submit
          </button>
        </div>
      </div>
      
      <div className="card mb-6">
        <div className="flex justify-between items-center mb-4">
          <div className="text-sm text-gray-600 dark:text-gray-400">
            Showing questions {startIdx + 1}-{endIdx} of {currentSheet.questions.length}
          </div>
          <div className="flex items-center gap-2">
            <button
              className="btn-secondary px-3 py-1"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            >
              Previous
            </button>
            <span className="text-sm">
              Page {currentPage} of {totalPages}
            </span>
            <button
              className="btn-secondary px-3 py-1"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            >
              Next
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currentQuestions.map((question) => (
            <div key={question.id} className="border border-gray-200 dark:border-gray-700 rounded-md p-4">
              <h3 className="text-lg font-medium mb-3">
                {question.number}.
              </h3>
              
              <div className="grid grid-cols-2 gap-2">
                {question.options.map((option) => (
                  <div key={option.id} className="flex items-center">
                    <input
                      type="radio"
                      id={`${question.id}-${option.id}`}
                      name={`question-${question.id}`}
                      className="mr-2"
                      checked={userAnswers[question.id] === option.id}
                      onChange={() => setUserAnswer(question.id, option.id)}
                    />
                    <label 
                      htmlFor={`${question.id}-${option.id}`}
                      className="text-gray-800 dark:text-gray-200"
                    >
                      {option.label}
                    </label>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="flex justify-between items-center">
        <div className="text-sm text-gray-600 dark:text-gray-400">
          {Object.keys(userAnswers).length} of {currentSheet.questions.length} questions answered
        </div>
        <div className="flex items-center gap-2">
          <button
            className="btn-secondary px-3 py-1"
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
          >
            Previous
          </button>
          <span className="text-sm">
            Page {currentPage} of {totalPages}
          </span>
          <button
            className="btn-secondary px-3 py-1"
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}