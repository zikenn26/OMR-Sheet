import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { ORMSheet, Question, Option, SubmissionResult, SubmissionSummary } from '@/types';

interface ORMState {
  sheets: ORMSheet[];
  currentSheet: ORMSheet | null;
  userAnswers: Record<string, string | null>;
  submissionResults: SubmissionResult[];
  submissionSummary: SubmissionSummary | null;
  isSubmitted: boolean;
  
  // Sheet actions
  createSheet: (title: string, description: string, timeLimit: number, startNumber: number, endNumber: number, marksPerCorrect: number, marksPerIncorrect: number) => void;
  setCurrentSheet: (sheetId: string) => void;
  
  // Question actions
  generateQuestions: () => void;
  setCorrectOption: (questionId: string, optionId: string) => void;
  
  // Submission actions
  setUserAnswer: (questionId: string, optionId: string | null) => void;
  submitAnswers: (timeTaken: number) => void;
  resetSubmission: () => void;
  
  // Answer key actions
  setAnswerKey: (answerKey: Record<number, string>) => void;
}

const OPTION_LABELS = ['A', 'B', 'C', 'D'];

export const useORMStore = create<ORMState>((set, get) => ({
  sheets: [],
  currentSheet: null,
  userAnswers: {},
  submissionResults: [],
  submissionSummary: null,
  isSubmitted: false,
  
  createSheet: (title, description, timeLimit, startNumber, endNumber, marksPerCorrect, marksPerIncorrect) => {
    const newSheet: ORMSheet = {
      id: uuidv4(),
      title,
      description,
      timeLimit,
      startNumber,
      endNumber,
      questions: [],
      createdAt: new Date(),
      marksPerCorrect,
      marksPerIncorrect
    };
    
    set((state) => ({
      sheets: [...state.sheets, newSheet],
      currentSheet: newSheet,
    }));
  },
  
  setCurrentSheet: (sheetId) => {
    const sheet = get().sheets.find((s) => s.id === sheetId) || null;
    set({ currentSheet: sheet, userAnswers: {}, isSubmitted: false, submissionResults: [], submissionSummary: null });
  },
  
  generateQuestions: () => {
    set((state) => {
      if (!state.currentSheet) return state;
      
      const { startNumber, endNumber } = state.currentSheet;
      const questions: Question[] = [];
      
      for (let i = startNumber; i <= endNumber; i++) {
        const options: Option[] = OPTION_LABELS.map(label => ({
          id: uuidv4(),
          label,
          text: label
        }));
        
        questions.push({
          id: uuidv4(),
          number: i,
          options,
          correctOption: null
        });
      }
      
      const updatedSheet = {
        ...state.currentSheet,
        questions
      };
      
      return {
        currentSheet: updatedSheet,
        sheets: state.sheets.map((s) => (s.id === updatedSheet.id ? updatedSheet : s)),
      };
    });
  },
  
  setCorrectOption: (questionId, optionId) => {
    set((state) => {
      if (!state.currentSheet) return state;
      
      const updatedQuestions = state.currentSheet.questions.map((q) =>
        q.id === questionId ? { ...q, correctOption: optionId } : q
      );
      
      const updatedSheet = {
        ...state.currentSheet,
        questions: updatedQuestions,
      };
      
      return {
        currentSheet: updatedSheet,
        sheets: state.sheets.map((s) => (s.id === updatedSheet.id ? updatedSheet : s)),
      };
    });
  },
  
  setUserAnswer: (questionId, optionId) => {
    set((state) => ({
      userAnswers: {
        ...state.userAnswers,
        [questionId]: optionId,
      },
    }));
  },
  
  submitAnswers: (timeTaken) => {
    const { currentSheet, userAnswers } = get();
    
    if (!currentSheet) return;
    
    const results: SubmissionResult[] = currentSheet.questions.map((question) => {
      const userAnswer = userAnswers[question.id] || null;
      const isCorrect = userAnswer === question.correctOption;
      
      return {
        questionId: question.id,
        questionNumber: question.number,
        userAnswer,
        correctAnswer: question.correctOption,
        isCorrect,
      };
    });
    
    const totalQuestions = results.length;
    const correctAnswers = results.filter((r) => r.isCorrect).length;
    const incorrectAnswers = results.filter((r) => !r.isCorrect && r.userAnswer !== null).length;
    const unansweredQuestions = results.filter((r) => r.userAnswer === null).length;
    
    const totalMarks = (correctAnswers * currentSheet.marksPerCorrect) - 
                       (incorrectAnswers * currentSheet.marksPerIncorrect);
    const maxPossibleMarks = totalQuestions * currentSheet.marksPerCorrect;
    const score = maxPossibleMarks > 0 ? (totalMarks / maxPossibleMarks) * 100 : 0;
    
    const summary: SubmissionSummary = {
      totalQuestions,
      correctAnswers,
      incorrectAnswers,
      unansweredQuestions,
      score,
      totalMarks,
      timeTaken,
    };
    
    set({
      submissionResults: results,
      submissionSummary: summary,
      isSubmitted: true,
    });
  },
  
  resetSubmission: () => {
    set({
      userAnswers: {},
      submissionResults: [],
      submissionSummary: null,
      isSubmitted: false,
    });
  },
  
  setAnswerKey: (answerKey) => {
    set((state) => {
      if (!state.currentSheet) return state;
      
      const updatedQuestions = state.currentSheet.questions.map((question) => {
        const correctLabel = answerKey[question.number];
        if (!correctLabel) return question;
        
        const correctOption = question.options.find(
          (option) => option.label.toUpperCase() === correctLabel.toUpperCase()
        );
        
        return {
          ...question,
          correctOption: correctOption ? correctOption.id : question.correctOption
        };
      });
      
      const updatedSheet = {
        ...state.currentSheet,
        questions: updatedQuestions,
      };
      
      return {
        currentSheet: updatedSheet,
        sheets: state.sheets.map((s) => (s.id === updatedSheet.id ? updatedSheet : s)),
      };
    });
  }
}));