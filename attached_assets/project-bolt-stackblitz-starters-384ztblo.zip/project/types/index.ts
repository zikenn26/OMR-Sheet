export interface Question {
  id: string;
  number: number;
  options: Option[];
  correctOption: string | null;
}

export interface Option {
  id: string;
  label: string;
  text: string;
}

export interface ORMSheet {
  id: string;
  title: string;
  description: string;
  timeLimit: number; // in minutes
  startNumber: number;
  endNumber: number;
  questions: Question[];
  createdAt: Date;
  marksPerCorrect: number;
  marksPerIncorrect: number;
}

export interface SubmissionResult {
  questionId: string;
  questionNumber: number;
  userAnswer: string | null;
  correctAnswer: string | null;
  isCorrect: boolean;
}

export interface SubmissionSummary {
  totalQuestions: number;
  correctAnswers: number;
  incorrectAnswers: number;
  unansweredQuestions: number;
  score: number;
  totalMarks: number;
  timeTaken: number; // in seconds
}